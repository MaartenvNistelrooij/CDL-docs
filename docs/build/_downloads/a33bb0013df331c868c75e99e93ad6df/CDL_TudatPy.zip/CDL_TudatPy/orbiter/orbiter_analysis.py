# General imports
import numpy as np
import os
from matplotlib import pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable

# Tudatpy imports
from tudatpy.util import result2array
from tudatpy.kernel import constants
from tudatpy.kernel import numerical_simulation
from tudatpy.kernel.numerical_simulation import propagation_setup, environment_setup
from tudatpy.kernel.astro import element_conversion

# CDL imports
from src import Orbiter, SolarSystemConstants, TrajectoryAnalysis
from orbiter_inputs import save_analysis_plots, central_body, spacecraft_name, vehicle_mass, \
                            radiation_pressure_coefficient, reference_area, simulation_start_epoch, simulation_time, \
                            semi_major_axis, eccentricity, inclination, raan, aop, tr_anom, minimum_elevation, \
                            gs_latitude, gs_longitude, gs_name, rs_central_body, rs_name, rs_semi_major_axis, \
                            rs_eccentricity, rs_inclination, rs_raan, rs_aop, rs_tr_anom, field_of_view, \
                            acceleration_settings_on_vehicle, dependent_variables_to_save


def main():

    ###########################################################################
    # Settings based on inputs
    ###########################################################################

    simulation_end_epoch = simulation_start_epoch + simulation_time

    initial_state_cartesian = element_conversion.keplerian_to_cartesian_elementwise(
        gravitational_parameter=SolarSystemConstants.MARS_GRAVITATIONAL_PARAMETER,
        semi_major_axis=semi_major_axis,
        eccentricity=eccentricity,
        inclination=inclination,
        longitude_of_ascending_node=raan,
        argument_of_periapsis=aop,
        true_anomaly=tr_anom
    )

    rs_initial_state = element_conversion.keplerian_to_cartesian_elementwise(
        gravitational_parameter=SolarSystemConstants.EARTH_GRAVITATIONAL_PARAMETER,
        semi_major_axis=rs_semi_major_axis,
        eccentricity=rs_eccentricity,
        inclination=rs_inclination,
        longitude_of_ascending_node=rs_raan,
        argument_of_periapsis=rs_aop,
        true_anomaly=rs_tr_anom
    )

    ###########################################################################
    # Propagate trajectory
    ###########################################################################
    # Create system of bodies
    bodies = Orbiter.create_system_of_bodies(
        central_body,
        vehicle_mass,
        spacecraft_name,
        radiation_pressure_coefficient,
        reference_area,
        acceleration_settings_on_vehicle,
        rs_name,
        rs_central_body
    )

    # Create integrator and propagator settings
    integrator_settings, propagator_settings = Orbiter.create_integrator_and_propagator_settings(
        bodies,
        central_body,
        simulation_start_epoch,
        simulation_end_epoch,
        initial_state_cartesian,
        spacecraft_name,
        acceleration_settings_on_vehicle,
        dependent_variables_to_save
    )

    # Create ephemeris for spacecraft
    environment_setup.add_empty_tabulated_ephemeris(bodies, spacecraft_name)
    # Create ephemeris for relay satellite
    environment_setup.add_empty_tabulated_ephemeris(bodies, rs_name)

    # Propagate trajectory of spacecraft
    dynamics_simulator = numerical_simulation.SingleArcSimulator(
        bodies,
        integrator_settings,
        propagator_settings,
        set_integrated_result=True,
        print_dependent_variable_data=True)

    # Retrieve state history and dependent variables history
    state_history = result2array(dynamics_simulator.state_history)
    dependent_variables_history = result2array(dynamics_simulator.dependent_variable_history)

    # Rename variables history for simplicity
    time_history = state_history[:, 0]
    state_values_history = state_history[:, 1:]
    dependent_variables_values_history = dependent_variables_history[:, 1:]

    ###########################################################################
    # Line of sight to ground station
    ###########################################################################
    TrajectoryAnalysis.add_ground_station_simple(
        bodies,
        gs_name,
        gs_latitude,
        gs_longitude)

    los_to_gs_history, los_to_gs_time_history = Orbiter.line_of_sight_to_ground_station(
        bodies,
        time_history[0],
        time_history[-1],
        spacecraft_name,
        central_body,
        gs_name,
        minimum_elevation)

    ###########################################################################
    # Line of sight to relay satellite
    ###########################################################################
    # Retrieve state history of relay satellite
    rs_integrator_settings, rs_propagator_settings = Orbiter.create_integrator_and_propagator_settings(
        bodies,
        rs_central_body,
        simulation_start_epoch,
        simulation_end_epoch,
        rs_initial_state,
        rs_name
    )
    rs_dynamics_simulator = numerical_simulation.SingleArcSimulator(
        bodies,
        rs_integrator_settings,
        rs_propagator_settings,
        set_integrated_result=True,
        print_dependent_variable_data=False)

    los_to_rs_history, los_to_rs_time_history = Orbiter.line_of_sight_to_relay_satellite(
        bodies,
        time_history[0],
        time_history[-1],
        central_body,
        spacecraft_name,
        rs_central_body,
        rs_name
    )

    ###########################################################################
    # Compute whether on day or night side of central body
    ###########################################################################
    day_night_values_history, day_night_time_history = Orbiter.planet_day_night_side(
        bodies,
        time_history[0],
        time_history[-1],
        spacecraft_name)

    ###########################################################################
    # Compute eclipses
    ###########################################################################
    eclipses_history, eclipses_time_history = Orbiter.eclipses_wrt_sun(
        bodies,
        time_history[0],
        time_history[-1],
        spacecraft_name,
        central_body)

    ###########################################################################
    # Compute ground coverage
    ###########################################################################

    # Obtain required simulation results
    altitude = dependent_variables_values_history[:, 0]
    latitude = dependent_variables_values_history[:, 2] * 180 / np.pi
    longitude = dependent_variables_values_history[:, 3] * 180 / np.pi

    lon_grid, lat_grid, ground_track_grid, number_of_visitations_grid, shortest_revisit_time_grid, \
        mean_revisit_time_grid, longest_revisit_time_grid, percentage_surface_covered, lat_min, lat_max = \
        Orbiter.ground_coverage(central_body,
                                altitude,
                                longitude,
                                latitude,
                                time_history,
                                simulation_time,
                                semi_major_axis,
                                field_of_view)

    print()
    print('Latitude range covered: ', lat_min, ' to ', lat_max, 'degrees')
    print()
    print('Percentage of planet surface covered: ', percentage_surface_covered, '%')

    ###########################################################################
    # Save data
    ###########################################################################
    current_dir = os.path.dirname(__file__) + '/'
    names = os.listdir(current_dir)
    existing_cases = []
    for name in names:
        if os.path.isdir(name) and name != '__pycache__':
            existing_cases.append(name)
    number_of_cases = len(existing_cases)
    case_dir = 'Orbiter_' + str(number_of_cases+1)
    plots_dir = case_dir + '/orbiter_analysis_plots/'
    data_dir = case_dir + '/orbiter_analysis_data/'

    data_path = current_dir + data_dir
    if not os.path.isdir(data_path):
        os.makedirs(data_path)

    np.savetxt(case_dir + '/inputs.txt',
               np.column_stack([['Central body ', 'Spacecraft name ', 'Vehicle mass [kg] ', 'Radiation pressure coefficient ',
                                 'Reference area [m2] ', 'Start epoch [s] ', 'Simulation time [s] ', 'a [m] ', 'e [-] ', 'i [rad] ',
                                 'RAAN [rad] ', 'AoP [rad] ', 'Theta [rad] ', 'GS min elevation [rad] ', 'GS latitude [rad] ',
                                 'GS longitude [rad] ', 'GS name ', 'RS Central body ', 'RS name ', 'RS a [m] ', 'RS e [-] ',
                                 'RS i [rad] ', 'RS RAAN [rad] ', 'RS AoP [rad] ', 'RS theta [rad] ', 'Field of view [deg] '],
                                [central_body, spacecraft_name, vehicle_mass, radiation_pressure_coefficient, reference_area,
                                 simulation_start_epoch, simulation_time, semi_major_axis, eccentricity, inclination,
                                 raan, aop, tr_anom, minimum_elevation, gs_latitude, gs_longitude, gs_name, rs_central_body,
                                 rs_name, rs_semi_major_axis, rs_eccentricity, rs_inclination, rs_raan, rs_aop, rs_tr_anom,
                                 field_of_view]]),
               header='Variable  Quantity', fmt="%s")
    np.savetxt(data_path + 'state.txt',
               np.column_stack([time_history, state_values_history]),
               header='time[s] \t x[m] \t y[m] \t z[m] \t vx[m/s] \t vy[m/s] \t vz[m/s]')

    dep_var_header = 'Time [s]'
    for i in range(len(dependent_variables_values_history[0])):
        dep_var_header += '\t ' + str(i)
    np.savetxt(data_path + 'dependent_variables.txt',
               np.column_stack([time_history, dependent_variables_values_history]),
               header=dep_var_header)
    np.savetxt(data_path + 'los_to_ground_station.txt',
               np.column_stack([los_to_gs_time_history, los_to_gs_history]),
               header='time[s] \t LoS (1=LoS, 0=no LoS) [-]')
    np.savetxt(data_path + 'los_to_relay_satellite.txt',
               np.column_stack([los_to_rs_time_history, los_to_rs_history]),
               header='time[s] \t LoS (1=LoS, 0=no LoS) [-]')
    np.savetxt(data_path + 'planet_day_night_side.txt',
               np.column_stack([day_night_time_history, day_night_values_history]),
               header='time[s] \t Day(=1)/Night(=0) [-]')
    np.savetxt(data_path + 'eclipses.txt',
               np.column_stack([eclipses_time_history, eclipses_history]),
               header='time[s] \t Eclipses (full light=1, umbra=0) [-]')
    np.savetxt(data_path + 'number_of_visitations.txt',
               np.column_stack([lon_grid.flatten(), lat_grid.flatten(), number_of_visitations_grid.flatten()]),
               header='longitude [deg] \t latitude [deg] \t Number of visitations [-]'
               )
    np.savetxt(data_path + 'mean_revisit_time.txt',
               np.column_stack([lon_grid.flatten(), lat_grid.flatten(), mean_revisit_time_grid.flatten()]),
               header='longitude [deg] \t latitude [deg] \t Mean revisit time [s]'
               )
    np.savetxt(data_path + 'shortest_revisit_time.txt',
               np.column_stack([lon_grid.flatten(), lat_grid.flatten(), shortest_revisit_time_grid.flatten()]),
               header='longitude [deg] \t latitude [deg] \t Shortest revisit time [s]'
               )
    np.savetxt(data_path + 'longest_revisit_time.txt',
               np.column_stack([lon_grid.flatten(), lat_grid.flatten(), longest_revisit_time_grid.flatten()]),
               header='longitude [deg] \t latitude [deg] \t Longest revisit time [s]'
               )
    with open(data_path + 'simple_characteristics.txt', 'w') as fp:
        fp.write(f'Minimum latitude [deg]: {str(lat_min)}\n')
        fp.write(f'Maximum latitude [deg]: {str(lat_max)}\n')
        fp.write(f'Surface covered [%]: {str(percentage_surface_covered)}\n')

    ###########################################################################
    # Make and save plots
    ###########################################################################
    if save_analysis_plots:
        plots_path = current_dir + plots_dir
        if not os.path.isdir(plots_path):
            os.makedirs(plots_path)

        # Line of sight with respect to ground station
        plt.figure()
        plt.plot((los_to_gs_time_history - simulation_start_epoch)/ constants.JULIAN_DAY, los_to_gs_history,
                  label = "LoS: 1 \nNo LoS: 0")
        plt.legend(loc='upper right', framealpha=0.9)
        plt.xlabel('time [days]')
        plt.ylabel('line of sight (LoS) [-]')
        plt.savefig(plots_path + 'time_lineOfSightToGS.pdf', bbox_inches='tight')
        plt.close()

        # Line of sight with respect to relay satellite
        plt.figure()
        plt.plot((los_to_rs_time_history - simulation_start_epoch) / constants.JULIAN_DAY, los_to_rs_history,
                 label = "LoS: 1 \nNo LoS: 0")
        plt.legend(loc='upper right', framealpha=0.9)
        plt.xlabel('time [days]')
        plt.ylabel('line of sight [-]')
        plt.savefig(plots_path + 'time_lineOfSightToRSat.pdf', bbox_inches='tight')
        plt.close()

        # Day and night side
        plt.figure()
        plt.plot((day_night_time_history - simulation_start_epoch) / constants.JULIAN_DAY, day_night_values_history,
                 label = 'Day: 1 \nNight: 0')
        plt.legend(loc='upper right', framealpha=0.9)
        plt.xlabel('time [days]')
        plt.ylabel('day/night side of the planet [-]')
        plt.savefig(plots_path + 'time_dayNightSide.pdf', bbox_inches='tight')
        plt.close()

        # Eclipses
        plt.figure()
        plt.plot((eclipses_time_history - simulation_start_epoch) / constants.JULIAN_DAY, eclipses_history,
                 label = 'Umbra: 0 \nLight: 1\nPenumbra: ]0,1[')
        plt.legend(loc = 'upper right', framealpha = 0.9)
        plt.xlabel('time [days]')
        plt.ylabel('eclipses [-]')
        plt.savefig(plots_path + 'time_eclipses.pdf', bbox_inches='tight')
        plt.close()

        # Ground coverage
        plt.figure()
        plt.pcolormesh(lon_grid, lat_grid, ground_track_grid, cmap=plt.cm.Reds, shading='auto')
        plt.gca().set_aspect('equal')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        plt.savefig(plots_path + 'groundCoverage.pdf', bbox_inches='tight')
        plt.close()

        # Revisit time
        upper_colorbar_limit = mean_revisit_time_grid.max() / 3600.
        lower_colorbar_limit = 0.

        plt.figure()
        pcm = plt.pcolormesh(lon_grid, lat_grid, mean_revisit_time_grid / 3600, cmap=plt.cm.hot,
                            vmin=lower_colorbar_limit, vmax=upper_colorbar_limit, shading='auto')
        plt.xlabel('Longitude [deg]')
        plt.ylabel('Latitude [deg]')
        ax = plt.gca()
        ax.set_aspect('equal')
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.05)
        cbar = plt.colorbar(pcm, cax=cax)
        cbar.set_label('Mean revisit time [hrs]')
        plt.savefig(plots_path + 'groundTrack_meanRevisitTime.pdf', bbox_inches='tight')
        plt.close()

    ###########################################################################
    return 0

if __name__ == "__main__":
    main()