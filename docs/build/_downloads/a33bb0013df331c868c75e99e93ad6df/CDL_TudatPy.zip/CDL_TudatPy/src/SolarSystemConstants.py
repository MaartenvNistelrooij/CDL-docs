
# J. J. Lissauer and I. de Pater. Fundamental Planetary Sciences. Cambridge University Press, updated edition, 2019.
SOLAR_LUMINOSITY = 3.827e26  # [W]

# Equatorial radii - Unit: [m]
SUN_EQUATORIAL_RADIUS = 695700000.0  # NASA, https://nssdc.gsfc.nasa.gov/planetary/factsheet/sunfact.html
MERCURY_EQUATORIAL_RADIUS = 2440500.0  # NASA, https://nssdc.gsfc.nasa.gov/planetary/factsheet/mercuryfact.html
VENUS_EQUATORIAL_RADIUS = 6051800.0  # NASA, https://nssdc.gsfc.nasa.gov/planetary/factsheet/venusfact.html
EARTH_EQUATORIAL_RADIUS = 6378136.6  # IERS, 2010
MOON_EQUATORIAL_RADIUS = 1738100.0  # NASA, https://nssdc.gsfc.nasa.gov/planetary/factsheet/moonfact.html
MARS_EQUATORIAL_RADIUS = 3396200.0  # NASA, https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html
JUPITER_EQUATORIAL_RADIUS = 71492000.0  # J. J. Lissauer and I. de Pater. Fundamental Planetary Sciences. Cambridge University Press, updated edition, 2019.
SATURN_EQUATORIAL_RADIUS = 60268000.0  # J. J. Lissauer and I. de Pater. Fundamental Planetary Sciences. Cambridge University Press, updated edition, 2019.
URANUS_EQUATORIAL_RADIUS = 25559000.0  # J. J. Lissauer and I. de Pater. Fundamental Planetary Sciences. Cambridge University Press, updated edition, 2019.
NEPTUNE_EQUATORIAL_RADIUS = 24766000.0  # J. J. Lissauer and I. de Pater. Fundamental Planetary Sciences. Cambridge University Press, updated edition, 2019.
PLUTO_EQUATORIAL_RADIUS = 1188000.0  # NASA, https://nssdc.gsfc.nasa.gov/planetary/factsheet/plutofact.html

# Gravitational parameters (JPL, 2012). Unit: [m^3 s^-2]
SUN_GRAVITATIONAL_PARAMETER = 1.32712440018e20
MERCURY_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 6023600.0
VENUS_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 408523.71
EARTH_GRAVITATIONAL_PARAMETER = 3.986004418E14
MOON_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER /( 328900.56 * ( 1.0 + 81.30059 ) )
MARS_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 3098708.0
JUPITER_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 1047.3486
SATURN_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 3497.898
URANUS_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 22902.98
NEPTUNE_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 19412.24
PLUTO_GRAVITATIONAL_PARAMETER = SUN_GRAVITATIONAL_PARAMETER / 1.35e8
