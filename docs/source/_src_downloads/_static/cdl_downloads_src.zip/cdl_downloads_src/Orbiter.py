# General imports
import numpy as np
from typing import Tuple

# Tudatpy imports
import tudatpy
from tudatpy.kernel import constants
from tudatpy.kernel.interface import spice
from tudatpy.kernel.numerical_simulation import environment_setup
from tudatpy.kernel.numerical_simulation import propagation_setup
from tudatpy.kernel.astro import fundamentals

# CDL imports
from src import SolarSystemConstants

# Definition of default number of output points
POINTS_PER_DAY = 144


###########################################################################
def create_system_of_bodies (central_body: str,
                             vehicle_mass: float,
                             spacecraft_name: str,
                             radiation_pressure_coefficient: float = None,
                             reference_area: float = None,
                             acceleration_settings_on_vehicle: dict = None,
                             relay_satellite_name: str = None,
                             relay_satellite_body: str = None) -> \
    tudatpy.kernel.numerical_simulation.environment.SystemOfBodies:
    """
    Creates the system of bodies, including required celestial bodies, spacecraft to propagate and relay satellite.
    Behavior associated with defaults:
    - A solar radiation pressure interface is only created if BOTH the radiation pressure coefficient and reference area
    are provided.
    - If no acceleration settings are provided, the only bodies that are created are the spacecraft central body and the
    relay satellite central body.
    - The relay satellite is only created if BOTH the relay satellite name and central body are provided.
    """

    # Check if information has been provided properly
    if (relay_satellite_name is None and relay_satellite_body is not None) or \
            (relay_satellite_name is not None and relay_satellite_body is None):
        raise RuntimeError('To use a relay satellite, it is necessary to provide both its name and central body!')

    if (radiation_pressure_coefficient is not None and reference_area is None) or \
            (radiation_pressure_coefficient is None and reference_area is not None):
        raise RuntimeError('To use SRP, it is necessary to provide both the reference area and radiation pressure coefficient!')

    ###########################################################################
    # Create celestial bodies
    ###########################################################################
    # Load spice kernels
    spice.load_standard_kernels()

    # Create settings for celestial bodies
    if acceleration_settings_on_vehicle is not None:
        bodies_to_create = list(acceleration_settings_on_vehicle.keys())
    else:
        bodies_to_create = [central_body]

    if relay_satellite_body is not None:
        if relay_satellite_body not in bodies_to_create:
            bodies_to_create.append(relay_satellite_body)

    global_frame_origin = central_body
    global_frame_orientation = "ECLIPJ2000"
    body_settings = environment_setup.get_default_body_settings(
        bodies_to_create, global_frame_origin, global_frame_orientation)

    bodies = environment_setup.create_system_of_bodies(body_settings)

    ###########################################################################
    # Create spacecraft
    ###########################################################################
    bodies.create_empty_body(spacecraft_name)
    bodies.get_body(spacecraft_name).set_constant_mass(vehicle_mass)

    # Create solar radiation pressure environment
    if (reference_area is not None) and (radiation_pressure_coefficient is not None) and ('Sun' in bodies_to_create):
        occulting_bodies = [central_body]
        radiation_pressure_settings = environment_setup.radiation_pressure.cannonball("Sun",
                                                                                      reference_area,
                                                                                      radiation_pressure_coefficient,
                                                                                      occulting_bodies)
        environment_setup.add_radiation_pressure_interface(bodies, spacecraft_name, radiation_pressure_settings)

    ###########################################################################
    # Create relay satellite
    ###########################################################################
    if relay_satellite_name is not None:
        bodies.create_empty_body(relay_satellite_name)
        bodies.get_body(relay_satellite_name).set_constant_mass(vehicle_mass)

    ###########################################################################
    # Return
    ###########################################################################
    return bodies


###########################################################################
def create_integrator_and_propagator_settings (bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                                               central_body: str,
                                               simulation_start_epoch: float,
                                               simulation_end_epoch: float,
                                               initial_state,
                                               spacecraft_name,
                                               acceleration_settings_on_vehicle: dict = None,
                                               dependent_variables_to_save: list = None) -> \
        Tuple[tudatpy.kernel.numerical_simulation.propagation_setup.integrator.IntegratorSettings,
              tudatpy.kernel.numerical_simulation.propagation_setup.propagator.TranslationalStatePropagatorSettings]:
    """
    Creates the integrator settings and propagator settings, returned as the tuple (integrator_settings, propagator_settings).
    Propagator: Cowell
    Integrator: RKDP8(7) with 10^-8 tolerance (absolute and relative)
    Behavior associated with defaults:
    - If no acceleration settings are provided, only point-mass acceleration from the central body is created.
    """

    ###########################################################################
    # Create accelerations
    ###########################################################################
    # Define bodies that are propagated and their central bodies of propagation
    bodies_to_propagate = [spacecraft_name]
    central_bodies = [central_body]

    # Define accelerations acting on vehicle (a dictionary)
    if acceleration_settings_on_vehicle is None:
        acceleration_settings_on_vehicle = {
            central_body: [propagation_setup.acceleration.point_mass_gravity()]
        }

    # Create global accelerations dictionary
    acceleration_settings = {spacecraft_name: acceleration_settings_on_vehicle}

    acceleration_models = propagation_setup.create_acceleration_models(
        bodies,
        acceleration_settings,
        bodies_to_propagate,
        central_bodies
    )

    ############################################################################
    # Create propagator settings
    ###########################################################################
    # Create termination settings
    termination_condition = propagation_setup.propagator.time_termination(simulation_end_epoch)

    # Create propagation settings.
    current_propagator = propagation_setup.propagator.cowell
    if dependent_variables_to_save is not None:
        propagator_settings = propagation_setup.propagator.translational(
            central_bodies,
            acceleration_models,
            bodies_to_propagate,
            initial_state,
            termination_condition,
            current_propagator,
            dependent_variables_to_save
        )
    else:
        propagator_settings = propagation_setup.propagator.translational(
            central_bodies,
            acceleration_models,
            bodies_to_propagate,
            initial_state,
            termination_condition,
            current_propagator
        )

    ############################################################################
    # Create integrator settings
    ###########################################################################
    current_coefficient_set = propagation_setup.integrator.RKCoefficientSets.rkdp_87
    # Define absolute and relative tolerance
    current_tolerance = 10.0 ** -8
    initial_time_step = 10 # s
    # Maximum step size: inf; minimum step size: eps
    integrator_settings = propagation_setup.integrator.runge_kutta_variable_step_size(simulation_start_epoch,
                                                                                      initial_time_step,
                                                                                      current_coefficient_set,
                                                                                      np.finfo(float).eps,
                                                                                      np.inf,
                                                                                      current_tolerance,
                                                                                      current_tolerance)

    ###########################################################################
    # Return
    ###########################################################################
    return integrator_settings, propagator_settings


###########################################################################
def line_of_sight_to_ground_station (bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                                     start_epoch: float,
                                     end_epoch: float,
                                     spacecraft_name: str,
                                     central_body: str,
                                     ground_station_name: str,
                                     minimum_elevation: float,
                                     ground_station_body: str = 'Earth',
                                     points_per_day: float = POINTS_PER_DAY) -> Tuple[np.ndarray,np.ndarray]:
    """
    Determine whether there is line of sight (LoS) to a ground station, taking into account when the spacecraft is \
    behind the central body and the minimum elevation required by the ground station. Takes values: 1 if there is \
    LoS, 0 if there is not.
    Default values:
    - Number of points per day
    - Ground station body is Earth

    Returns results as tuple: LoS_values_history, time_history
    """

    ###########################################################################
    # Get elevation history as seen from ground station
    ###########################################################################
    # Determine time history
    results_time_history = np.arange(start_epoch, end_epoch, constants.JULIAN_DAY / points_per_day)

    # Retrieve elevation history
    elevation_values_history = environment_setup.get_target_elevation_angles(bodies.get_body(ground_station_body),
                                                                             bodies.get_body(spacecraft_name),
                                                                             ground_station_name,
                                                                             results_time_history)

    ###########################################################################
    # Get value of shadow function with respect to ground station
    ###########################################################################
    shadow_function_values_history = np.zeros(np.shape(results_time_history))

    # For calculating the shadow function, the central body position is used as the ground station position
    central_body_radius = spice.get_average_radius(central_body)
    for i in range(len(results_time_history)):
        shadow_function_values_history[i] = fundamentals.compute_shadow_function(
            bodies.get_body(ground_station_body).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3],
            0.0,        # Occulted body is the GS, therefore a point (radius = 0)
            bodies.get_body(central_body).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3],
            central_body_radius,
            bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3]
        )

    ###########################################################################
    # Determine when there is line of sight
    ###########################################################################
    line_of_sight_values_history = np.zeros(np.shape(results_time_history))

    for i in range(len(results_time_history)):
        if shadow_function_values_history[i] > 0 and elevation_values_history[i] >= minimum_elevation:
            line_of_sight_values_history[i] = 1
        else:
            line_of_sight_values_history[i] = 0

    return line_of_sight_values_history, results_time_history


###########################################################################
def line_of_sight_to_relay_satellite (bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                                      start_epoch: float,
                                      end_epoch: float,
                                      central_body: str,
                                      spacecraft_name: str,
                                      relay_sat_central_body: str,
                                      relay_sat_name: str,
                                      points_per_day: float = POINTS_PER_DAY) -> Tuple[np.ndarray,np.ndarray]:
    """
    Determine whether there is line of sight (LoS) to a relay satellite, taking into account occultations due to \
    the spacecraft's central body and to the relay-satellite's central body. Takes values: 1 if there is \
    LoS, 0 if there is not.
    Default values:
    - Number of points per day

    Returns results as tuple: LoS_values_history, time_history
    """

    ###########################################################################
    # Get value of shadow function
    ###########################################################################
    # Determine time history
    results_time_history = np.arange(start_epoch, end_epoch, constants.JULIAN_DAY / points_per_day)

    # Get shadow functions considering the two central planets as occulting bodies
    shadow_function_cb_values_history = np.zeros(np.shape(results_time_history))   # central_body as occulting body
    shadow_function_rscb_values_history = np.zeros(np.shape(results_time_history)) # relay sat central body as occulting body

    central_body_radius = spice.get_average_radius(central_body)
    rs_central_body_radius = spice.get_average_radius(relay_sat_central_body)

    for i in range(len(results_time_history)):

        shadow_function_cb_values_history[i] = fundamentals.compute_shadow_function(
            bodies.get_body(relay_sat_name).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3],
            0.0,        # Occulted body is the satellite, therefore a point (radius = 0)
            bodies.get_body(central_body).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3],
            central_body_radius,
            bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3]
        )

        shadow_function_rscb_values_history[i] = fundamentals.compute_shadow_function(
            bodies.get_body(relay_sat_name).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3],
            0.0,        # Occulted body is the satellite, therefore a point (radius = 0)
            bodies.get_body(relay_sat_central_body).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3],
            rs_central_body_radius,
            bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(results_time_history[i])[0:3]
        )

    ###########################################################################
    # Determine when there is line of sight
    ###########################################################################
    line_of_sight_values_history = np.zeros(np.shape(results_time_history))

    for i in range(len(results_time_history)):
        if shadow_function_cb_values_history[i] > 0 and shadow_function_rscb_values_history[i] > 0:
            line_of_sight_values_history[i] = 1
        else:
            line_of_sight_values_history[i] = 0

    return line_of_sight_values_history, results_time_history


###########################################################################
def planet_day_night_side(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                          start_epoch: float,
                          end_epoch: float,
                          spacecraft_name: str,
                          points_per_day: float = POINTS_PER_DAY) -> Tuple[np.ndarray,np.ndarray]:
    """
    Determines whether the sub-satellite point is in the day or night side of the planet (assuming day in half the \
    planet and night in the other half). Takes the values: 0 is sub-satellite point is on the night side, 1 if on \
    the day side.
    Default values:
    - Number of points per day

    Returns results as tuple: day_night_values_history, time_history
    """

    # Determine time history
    day_night_time_history = np.arange(start_epoch, end_epoch, constants.JULIAN_DAY / points_per_day)
    # Create array to hold values
    day_night_values_history = np.zeros(np.shape(day_night_time_history))

    for i in range(len(day_night_time_history)):
        # Get spacecraft and sun position
        spacecraft_position = bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(
            day_night_time_history[i])[0:3]
        sun_position = bodies.get_body("Sun").state_in_base_frame_from_ephemeris(day_night_time_history[i])[0:3]

        # Calculate arccos
        v1 = spacecraft_position / np.linalg.norm(spacecraft_position)
        v2 = sun_position / np.linalg.norm(sun_position)
        angle_arccos = np.dot(v1, v2)

        # Calculate angle. Manually select value for boundary cases to deal with numerical errors
        if angle_arccos > 1:
            angle = 0
        elif angle_arccos < -1:
            angle = np.pi
        else:
            angle = np.arccos(angle_arccos)

        # If angle <= pi/2 then day side. Night side otherwise
        if angle <= np.pi / 2:
            day_night_values_history[i] = 1
        else:
            day_night_values_history[i] = 0

    return day_night_values_history, day_night_time_history


###########################################################################
def eclipses_wrt_sun(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                      start_epoch: float,
                      end_epoch: float,
                      spacecraft_name: str,
                      central_body: str,
                      points_per_day: float = POINTS_PER_DAY) -> Tuple[np.ndarray,np.ndarray]:
    """
    Computes the occurrence of eclipses (with respect to the Sun). Takes the values: \
    1 if spacecraft in full light, 0 if in umbra, ]0,1[ if in penumbra.
    Default values:
    - Number of points per day

    Returns eclipses as tuple: eclipse_values_history, time_history
    """

    # Determine time history
    eclipse_time_history = np.arange(start_epoch, end_epoch, constants.JULIAN_DAY / points_per_day)

    # Create array to hold eclipse values
    eclipse_values_history = np.zeros(np.shape(eclipse_time_history))

    # Retrieve radius of central body and sun
    central_body_radius = spice.get_average_radius(central_body)
    sun_radius = spice.get_average_radius('Sun')

    # Compute shadow function
    for i in range(len(eclipse_time_history)):
        eclipse_values_history[i] = fundamentals.compute_shadow_function(
            bodies.get_body('Sun').state_in_base_frame_from_ephemeris(eclipse_time_history[i])[0:3],
            sun_radius,
            bodies.get_body(central_body).state_in_base_frame_from_ephemeris(eclipse_time_history[i])[0:3],
            central_body_radius,
            bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(eclipse_time_history[i])[0:3]
        )

    return eclipse_values_history, eclipse_time_history


###########################################################################
def ground_coverage(central_body: str,
                    altitude: np.ndarray,
                    longitude: np.ndarray,
                    latitude: np.ndarray,
                    time_history: np.array,
                    simulation_time: float,
                    semi_major_axis: float,
                    field_of_view: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray,
                                                   np.ndarray, np.ndarray, np.ndarray, float]:

    # TODO: write description for this function
    # TODO: make this retrieve it from Tudat, if still possible?

    if central_body == 'Sun':
        gravitational_parameter = SolarSystemConstants.SUN_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.SUN_EQUATORIAL_RADIUS
    elif central_body == 'Mercury':
        gravitational_parameter = SolarSystemConstants.MERCURY_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.MERCURY_EQUATORIAL_RADIUS
    elif central_body == 'Venus':
        gravitational_parameter = SolarSystemConstants.VENUS_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.VENUS_EQUATORIAL_RADIUS
    elif central_body == 'Earth':
        gravitational_parameter = SolarSystemConstants.EARTH_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.EARTH_EQUATORIAL_RADIUS
    elif central_body == 'Mars':
        gravitational_parameter = SolarSystemConstants.MARS_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.MARS_EQUATORIAL_RADIUS
    elif central_body == 'Jupiter':
        gravitational_parameter = SolarSystemConstants.JUPITER_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.JUPITER_EQUATORIAL_RADIUS
    elif central_body == 'Saturn':
        gravitational_parameter = SolarSystemConstants.SATURN_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.SATURN_EQUATORIAL_RADIUS
    elif central_body == 'Uranus':
        gravitational_parameter = SolarSystemConstants.URANUS_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.URANUS_EQUATORIAL_RADIUS
    elif central_body == 'Neptune':
        gravitational_parameter = SolarSystemConstants.NEPTUNE_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.NEPTUNE_EQUATORIAL_RADIUS
    elif central_body == 'Pluto':
        gravitational_parameter = SolarSystemConstants.PLUTO_GRAVITATIONAL_PARAMETER
        central_body_radius = SolarSystemConstants.PLUTO_EQUATORIAL_RADIUS

    approximate_orbital_period = 2*np.pi * np.sqrt((semi_major_axis**3) / gravitational_parameter)

    swath_width = 2 * altitude * np.tan( field_of_view * np.pi/180)
    swath_angle = swath_width / (np.cos(latitude * np.pi/180.) * 2 * np.pi * central_body_radius)*360.

    lat_min = latitude.min()
    lat_max = latitude.max()

    print()
    print('Latitude range covered: ', lat_min, ' to ', lat_max, 'degrees')

    # Split the arrays where we cross the International Date Line (180 deg E/W) or when we reach min or max latitude
    longitude_split = []
    latitude_split = []
    time_history_split = []
    swath_angle_split = []
    next_starter = 0
    for i in range(len(latitude) - 2):
        gradient_sign_before = np.sign(latitude[i+1] - latitude[i])
        gradient_sign_after = np.sign(latitude[i+2] - latitude[i+1])

        # maximum latitude split
        if gradient_sign_before != gradient_sign_after:
            longitude_split.append(longitude[next_starter:(i + 1)])
            latitude_split.append(latitude[next_starter:(i + 1)])
            time_history_split.append(time_history[next_starter:(i+1)])
            swath_angle_split.append(swath_angle[next_starter:(i + 1)])
            next_starter = i + 1

        # International Date Line
        if longitude[i+1] < longitude[i]:
            longitude_split.append(longitude[next_starter:(i+1)])
            latitude_split.append(latitude[next_starter:(i+1)])
            time_history_split.append(time_history[next_starter:(i+1)])
            swath_angle_split.append(swath_angle[next_starter:(i+1)])
            next_starter = i+1

    longitude_split.append(longitude[next_starter:])
    latitude_split.append(latitude[next_starter:])
    time_history_split.append(time_history[next_starter:])
    swath_angle_split.append(swath_angle[next_starter:])

    # TODO: check if this part below is needed
    # indices_to_remove = []
    # for i in range(len(latitude_split)):
    #     if len(latitude_split[i]) == 0:
    #         indices_to_remove.append(i)
    # latitude_split = np.delete(latitude_split, indices_to_remove)
    # longitude_split = np.delete(longitude_split, indices_to_remove)
    # time_history_split = np.delete(time_history_split, indices_to_remove)

    # Initialize regular grid
    delta_lonlat = 0.5
    lon_list = np.arange(-180., 180.+delta_lonlat, delta_lonlat)
    lat_list = np.arange(-90., 90.+delta_lonlat, delta_lonlat)
    lon_grid, lat_grid = np.meshgrid(lon_list, lat_list)

    # Initialize matrices for calculation of various quantities across the planet
    number_of_visitations_grid = np.zeros((len(lat_list), len(lon_list)))
    last_visit_time_grid = np.zeros((len(lat_list), len(lon_list)))
    total_time_between_visits_grid = np.zeros((len(lat_list), len(lon_list)))
    minimum_revisit_time_grid = simulation_time * np.ones((len(lat_list), len(lon_list)))
    maximum_revisit_time_grid = simulation_time * np.ones((len(lat_list), len(lon_list)))
    mean_revisit_time_grid = simulation_time * np.ones((len(lat_list), len(lon_list)))

    from scipy.interpolate import interp1d
    # TODO: implement the 6d/Xd interpolator here instead of scipy's interp1d
    # Interpolate the simulated lonlats to the regular grid based on delta_lonlat
    # Consider each section of the track

    for i in range(len(latitude_split)):
        latitude_section = latitude_split[i]
        longitude_section = longitude_split[i]
        time_section = time_history_split[i]
        swath_angle_section = swath_angle_split[i]

        # Find missing pieces in the latitude grid, to add in the interpolation
        #Compare to previous latitude section to add at start, missing due to cutoff
        number_of_additions_in_front = 0.0
        number_of_additions_at_end = 0.0
        if i != 0:
            latitude_difference = latitude_split[i-1][-1] - latitude_split[i][0]
            if (latitude_difference > delta_lonlat and latitude_split[i-1][-1] > 0.) or (latitude_difference < -delta_lonlat and latitude_split[i-1][-1] < 0.0):
                number_of_additions_in_front = np.floor( abs(latitude_difference / delta_lonlat))
        # Compare to next latitude section to add at end, missing due to cutoff
        if i < len(latitude_split)-1:
            latitude_difference = latitude_split[i][-1] - latitude_split[i+1][0]
            if (latitude_difference > delta_lonlat and latitude_split[i][-1] < 0.0) or (latitude_difference < -delta_lonlat and latitude_split[i][-1] > 0.0):
                number_of_additions_at_end = np.floor(abs(latitude_difference / delta_lonlat))

        # Create interpolator functions for longitude and time based on latitude
        if len(latitude_section) > 1:
            interp_lon_func = interp1d(latitude_section, longitude_section, bounds_error=False, fill_value='extrapolate')
            interp_time_func = interp1d(latitude_section, time_section, bounds_error=False, fill_value='extrapolate')
            interp_swath_angle_func = interp1d(latitude_section, swath_angle_section, bounds_error=False, fill_value='extrapolate')

            # Create regular latitude list based on descending or ascending leg
            if latitude_section[0] > latitude_section[-1]:
                latitude_interpolated = np.arange(np.floor(latitude_section[0])+(1+number_of_additions_in_front)*delta_lonlat, np.ceil(latitude_section[-1])-(2+number_of_additions_at_end)*delta_lonlat, -delta_lonlat)
                difference_with_max = abs(latitude_interpolated[0] - lat_max)
                difference_with_min= abs(latitude_interpolated[-1] - lat_min)
                if (difference_with_max > delta_lonlat) and (difference_with_max < 3. *delta_lonlat):
                    number_of_additions = int(np.floor(difference_with_max / delta_lonlat))
                    for g in range(number_of_additions):
                        latitude_interpolated = np.insert(latitude_interpolated, 0, latitude_interpolated[0] + delta_lonlat)

                if (difference_with_min > delta_lonlat) and (difference_with_min < 3. * delta_lonlat):
                    number_of_additions = int(np.floor(difference_with_min / delta_lonlat))
                    for g in range(number_of_additions):
                        latitude_interpolated = np.insert(latitude_interpolated, len(latitude_interpolated),
                                                          latitude_interpolated[-1] - delta_lonlat)

            else:
                latitude_interpolated = np.arange(np.ceil(latitude_section[0])-(1+number_of_additions_in_front)*delta_lonlat, np.floor(latitude_section[-1])+(2+number_of_additions_at_end)*delta_lonlat, delta_lonlat)
                difference_with_max = abs(latitude_interpolated[-1] - lat_max)
                difference_with_min = abs(latitude_interpolated[0] - lat_min)
                if (difference_with_max > delta_lonlat) and (difference_with_max < 3. * delta_lonlat):
                    number_of_additions = int(np.floor(difference_with_max / delta_lonlat))
                    for g in range(number_of_additions):
                        latitude_interpolated = np.insert(latitude_interpolated, len(latitude_interpolated), latitude_interpolated[-1] + delta_lonlat)

                if (difference_with_min > delta_lonlat) and (difference_with_min < 3. * delta_lonlat):
                    number_of_additions = int(np.floor(difference_with_min / delta_lonlat))
                    for g in range(number_of_additions):
                        latitude_interpolated = np.insert(latitude_interpolated, 0,
                                                          latitude_interpolated[0] - delta_lonlat)

            # Interpolate to obtain longitude and time stamps
            longitude_interpolated = interp_lon_func(latitude_interpolated)
            time_interpolated = interp_time_func(latitude_interpolated)
            swath_angle_interpolated = interp_swath_angle_func(latitude_interpolated)

        # Calculate the visit parameter and revisit time where applicable
        for j in range(len(latitude_interpolated)):
            # Apply swath width
            lon_minus_original = np.around((longitude_interpolated[j] - swath_angle_interpolated[j] / 2), decimals=0)
            lon_plus_original = np.around((longitude_interpolated[j] + swath_angle_interpolated[j] / 2), decimals=0)
            lat_index = np.argwhere(lat_list == latitude_interpolated[j])

            # Split if outside nominal lonlat bounds
            if lon_minus_original < -180.0:
                if lon_plus_original > -180.:
                    lon_minus1 = -180.0
                    lon_plus1 = lon_plus_original
                    lon_minus2 = lon_minus_original + 360.
                    lon_plus2 = 180.
                    lon_minus_list = [lon_minus1, lon_minus2]
                    lon_plus_list = [lon_plus1, lon_plus2]
                else:
                    lon_minus_list = [lon_minus_original + 360]
                    lon_plus_list = [lon_plus_original + 360]
            elif lon_plus_original > 180.0:
                if lon_minus_original < 180.0:
                    lon_plus1 = 180.0
                    lon_minus1 = lon_minus_original
                    lon_plus2 = lon_plus_original - 360
                    lon_minus2 = -180.
                    lon_minus_list = [lon_minus1, lon_minus2]
                    lon_plus_list = [lon_plus1, lon_plus2]
                else:
                    lon_minus_list = [lon_minus_original - 360]
                    lon_plus_list = [lon_plus_original - 360]
            else:
                lon_minus_list = [lon_minus_original]
                lon_plus_list = [lon_plus_original]

            for l in range(len(lon_minus_list)):
                lon_minus = lon_minus_list[l]
                lon_plus = lon_plus_list[l]
                lon_index_min = np.argwhere(lon_list == lon_minus)
                lon_index_plus = np.argwhere(lon_list == lon_plus)


                # Loop all lon pixels at this latitude that are visited
                for k in np.arange(lon_index_min[0], lon_index_plus[0], 1):

                    if number_of_visitations_grid[lat_index, k] == 0:
                        number_of_visitations_grid[lat_index, k] += 1

                    # If second visit
                    elif number_of_visitations_grid[lat_index, k] == 1:
                        if minimum_revisit_time_grid[lat_index, k] == simulation_time:
                            time_difference = abs(time_interpolated[j] - last_visit_time_grid[lat_index, k])
                            if time_difference > (approximate_orbital_period / 4.):
                                number_of_visitations_grid[lat_index, k] += 1
                                minimum_revisit_time_grid[lat_index, k] = time_difference
                                maximum_revisit_time_grid[lat_index, k] = time_difference
                                total_time_between_visits_grid[lat_index, k] += time_difference

                    # if more than second visit
                    elif number_of_visitations_grid[lat_index, k] > 1:
                        new_revisit_time = abs(time_interpolated[j] - last_visit_time_grid[lat_index, k])
                        if new_revisit_time > (approximate_orbital_period / 4.):
                            number_of_visitations_grid[lat_index, k] += 1
                            total_time_between_visits_grid[lat_index, k] += new_revisit_time

                            if new_revisit_time < minimum_revisit_time_grid[lat_index, k]:
                                minimum_revisit_time_grid[lat_index, k] = new_revisit_time
                            if new_revisit_time > maximum_revisit_time_grid[lat_index, k]:
                                maximum_revisit_time_grid[lat_index, k] = new_revisit_time

                    last_visit_time_grid[lat_index, k] = time_interpolated[j]

    # Calculate mean revisit time
    for i in range(len(number_of_visitations_grid)):
        for j in range(len(number_of_visitations_grid[0])):
            if number_of_visitations_grid[i, j] > 1:
                mean_revisit_time_grid[i, j] = total_time_between_visits_grid[i, j] / (number_of_visitations_grid[i, j] - 1)

    ground_track_grid = number_of_visitations_grid.copy()
    ground_track_grid[np.where(ground_track_grid > 1)] = 1

    percentage_surface_covered = np.count_nonzero(number_of_visitations_grid) / number_of_visitations_grid.size * 100.

    return lon_grid, lat_grid, ground_track_grid, number_of_visitations_grid, minimum_revisit_time_grid, \
        mean_revisit_time_grid, maximum_revisit_time_grid, percentage_surface_covered
