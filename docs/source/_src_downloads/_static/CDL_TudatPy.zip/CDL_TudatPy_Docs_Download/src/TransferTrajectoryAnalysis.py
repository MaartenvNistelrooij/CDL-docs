# General imports
from typing import List, Tuple
import numpy as np

# Tudat imports
from tudatpy.kernel import constants
from tudatpy.kernel.trajectory_design import transfer_trajectory
from tudatpy.kernel.numerical_simulation import environment_setup
from tudatpy.kernel.math import interpolators
from tudatpy.util import result2array
import tudatpy

# CDL imports
import src.TrajectoryAnalysis
from src.SolarSystemConstants import SOLAR_LUMINOSITY

# Definition of default number of states per leg and per day
STATES_PER_LEG = 500
STATES_PER_DAY = 96

###########################################################################
def create_and_evaluate_transfer_trajectory (
        bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
        leg_type: tudatpy.kernel.trajectory_design.transfer_trajectory.TransferLegTypes,
        transfer_body_order: List[str],
        trajectory_parameters: List[float],
        departure_semi_major_axis: float = np.inf,
        departure_eccentricity: float = 0,
        arrival_semi_major_axis: float = np.inf,
        arrival_eccentricity: float = 0) -> tudatpy.kernel.trajectory_design.transfer_trajectory.TransferTrajectory:
    """
    Creation of transfer calculation object. Uses simplified system of bodies.
    With default values for departure and arrival orbit, pacecraft departs/arrives at/from the edge
    of sphere of influence.
    """

    # Define type of leg between bodies
    transfer_leg_settings, transfer_node_settings = transfer_trajectory.mga_transfer_settings(
        transfer_body_order,
        leg_type,
        departure_orbit = (departure_semi_major_axis, departure_eccentricity),
        arrival_orbit = (arrival_semi_major_axis, arrival_eccentricity) )

    # Create transfer calculation object
    transfer_trajectory_obj = transfer_trajectory.create_transfer_trajectory(bodies,
                                                                             transfer_leg_settings,
                                                                             transfer_node_settings,
                                                                             transfer_body_order,
                                                                             'Sun')

    # Convert list of trajectory parameters to appropriate format
    node_times, leg_free_parameters, node_free_parameters = convert_trajectory_parameters(transfer_trajectory_obj,
                                                                                          leg_type,
                                                                                          trajectory_parameters)

    # Evaluate trajectory
    transfer_trajectory_obj.evaluate(node_times, leg_free_parameters, node_free_parameters)

    return transfer_trajectory_obj

###########################################################################
def convert_trajectory_parameters (transfer_trajectory_obj: tudatpy.kernel.trajectory_design.transfer_trajectory.TransferTrajectory,
                                   leg_type: tudatpy.kernel.trajectory_design.transfer_trajectory.TransferLegTypes,
                                   trajectory_parameters: List[float],
                                   ) -> Tuple[ List[float], List[List[float]], List[List[float]] ]:
    """
    Gets inputs for transfer object from list of trajectory parameters
    Trajectory parameters specified according to the following order:
    - For unpowered_unperturbed_leg_type: trajectory_parameters = [node_times]
    - For dsm_velocity_based_leg_type: trajectory_parameters = [node_times,node_free_parameters,leg_free_parameters]
    """

    # Check type of leg
    if leg_type == transfer_trajectory.dsm_position_based_leg_type:
        raise RuntimeError('Parameters conversion for DSM position-based leg not yet supported')

    # Declare lists of transfer parameters
    node_times = list()
    leg_free_parameters = list()
    node_free_parameters = list()

    # Rename number of nodes and legs
    number_of_nodes = transfer_trajectory_obj.number_of_nodes
    number_of_legs = transfer_trajectory_obj.number_of_legs

    # Extract from trajectory parameters the lists with each type of parameters
    traj_parameters_node_times = trajectory_parameters[0:number_of_nodes]
    if leg_type == transfer_trajectory.dsm_velocity_based_leg_type:
        traj_parameters_node_free_parameters = trajectory_parameters[
                                               number_of_nodes:number_of_nodes + 3 * (number_of_nodes - 1)]
        traj_parameters_leg_free_parameters = trajectory_parameters[
                                              number_of_nodes + 3 * (number_of_nodes - 1):]

    # Get node times
    # 0th element of parameters_list: departure time
    node_times.append(traj_parameters_node_times[0])
    # Other elements of parameters_list: time of flight -> need to calculate gravity assist date
    accumulated_time = traj_parameters_node_times[0]
    for i in range(1, number_of_nodes):
        accumulated_time += traj_parameters_node_times[i]
        node_times.append(accumulated_time)

    # Get leg_free_parameters and node_free_parameters for the different types of trajectories
    if leg_type == transfer_trajectory.unpowered_unperturbed_leg_type:
        # One empty array for each leg
        for i in range(number_of_legs):
            leg_free_parameters.append( [] )
        # One empty array for each node
        for i in range(number_of_nodes):
            node_free_parameters.append( [] )
    elif leg_type == transfer_trajectory.dsm_velocity_based_leg_type:
        for i in range(number_of_legs):
            leg_free_parameters.append( [traj_parameters_leg_free_parameters[i]] )
        for i in range(number_of_nodes - 1):
            node_free_parameters.append( traj_parameters_node_free_parameters[3 * i:3 * i + 3] )
        # One empty array for the last node
        node_free_parameters.append( [] )

    return node_times, leg_free_parameters, node_free_parameters


###########################################################################
def get_state_history(transfer_trajectory_obj: tudatpy.kernel.trajectory_design.transfer_trajectory.TransferTrajectory,
                      bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                      reference_body: str = 'Sun',
                      states_per_leg: float = STATES_PER_LEG) -> Tuple[np.ndarray,np.ndarray]:
    """
    Returns the state history (and corresponding time history) with respect to the specified body as the tuple:
    - state_history, time_history
    Default values:
    - Reference body is the Sun
    - Number of states per leg
    """

    # Retrieve state and time history with respect to the Sun
    full_state_history_wrt_sun = result2array(transfer_trajectory_obj.states_along_trajectory(states_per_leg))
    time_history_wrt_sun = full_state_history_wrt_sun[:,0]
    state_history_wrt_sun = full_state_history_wrt_sun[:, 1:]

    if reference_body == 'Sun':     # Return state history with respect to the Sun
        return state_history_wrt_sun,time_history_wrt_sun

    else:                            # Retrieve and return state history with respect to other body
        central_body = 'Sun'
        reference_body_state = np.zeros(np.shape(state_history_wrt_sun))
        central_body_state = np.zeros(np.shape(state_history_wrt_sun))

        # Retrieve state history of reference body and central body
        for i in range(np.size(time_history_wrt_sun)):
            reference_body_state[i, :] = \
                bodies.get_body(reference_body).state_in_base_frame_from_ephemeris(time_history_wrt_sun[i])
            central_body_state[i, :] = \
                bodies.get_body(central_body).state_in_base_frame_from_ephemeris(time_history_wrt_sun[i])

        state_history_wrt_reference_body = state_history_wrt_sun + central_body_state - reference_body_state

        return state_history_wrt_reference_body, time_history_wrt_sun

###########################################################################
def total_solar_flux(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                     time_history:np.ndarray,
                     spacecraft_name: str) -> np.ndarray:
    """
    Calculates total incident solar flux history. Values are calculated at the time stamps provided as input.
    """

    # Create array to hold solar flux history
    solar_flux_history = np.zeros(np.shape(time_history))

    # Compute solar flux history
    for i in range(len(time_history)):
        position = bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(time_history[i])[0:3]
        solar_flux_history[i] = SOLAR_LUMINOSITY / (4 * np.pi * np.linalg.norm(position)**2)

    return solar_flux_history

###########################################################################
def angle_of_incidence(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                       time_history: np.ndarray,
                       spacecraft_name: str,
                       solar_array_orientation_reference: str) -> np.ndarray:
    """
    Calculates the angle of the incident solar radiation with respect to a direction normal to the solar arrays.
    Inputs:
    - solar_array_orientation_reference: direction perpendicular to solar array. Possibilities: Velocity, Sun,
    planets of solar system
    """

    # Retrieve state history
    state_history = np.zeros((np.size(time_history),6))
    for i in range(len(time_history)):
        state_history[i,:] = bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(time_history[i])

    if solar_array_orientation_reference == 'Velocity':
        normal_vector = state_history[:, 3:]
    elif solar_array_orientation_reference == 'Sun':
        normal_vector = -state_history[:, 0:3]
    elif solar_array_orientation_reference in {'Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus',
                                               'Neptune', 'Pluto'}:

        state_history_wrt_planet = np.zeros((np.size(time_history), 6))
        for i in range(len(time_history)):
            state_history_wrt_planet = \
                bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(time_history[i]) - \
                bodies.get_body(solar_array_orientation_reference).state_in_base_frame_from_ephemeris(time_history[i])
        normal_vector = -state_history_wrt_planet[:, 0:3]
    else:
        raise RuntimeError('Invalid reference for solar array orientation')

    angle_of_incidence_history = src.TrajectoryAnalysis.angle_wrt_normal_vector_history(state_history,
                                                                                        normal_vector)

    return angle_of_incidence_history

###########################################################################
def effective_solar_flux(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                         time_history: np.ndarray,
                         spacecraft_name: str,
                         solar_array_orientation_reference: str) -> np.ndarray:
    """
    Calculates the effective solar flux, i.e. the solar flux perpendicular to the solar array.
    Inputs:
    - solar_array_orientation_reference: direction perpendicular to solar array. Possibilities: Velocity, Sun,
    planets of solar system
    Default values:
    - Number of states per leg
    """

    angle_of_incidence_history = angle_of_incidence(bodies, time_history, spacecraft_name, solar_array_orientation_reference)

    solar_flux_history = total_solar_flux(bodies, time_history, spacecraft_name)

    effective_solar_flux_history = np.ndarray((np.size(solar_flux_history), 1))
    for i in range(np.size(solar_flux_history)):
        effective_solar_flux_history[i] = solar_flux_history[i] * np.cos(angle_of_incidence_history[i])

    return effective_solar_flux_history

###########################################################################
def link_budget(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                time_history: np.ndarray,
                spacecraft_name: str,
                frequency: float,
                transmitted_power: float,
                transmitter_antenna_gain: float,
                receiver_antenna_gain: float,
                reference_body: str = 'Earth') -> np.ndarray:
    """
    Calculates link budget with respect to the specified reference body.
    Values are calculated at the time stamps provided as input.
    Default values:
    - Earth as reference body
    """

    # Create array to hold link budget
    link_budget_history = np.zeros(np.shape(time_history))

    # Compute variables
    wavelength = constants.SPEED_OF_LIGHT / frequency

    # Compute link budget
    for i in range(len(time_history)):
        position_wrt_reference_body = \
            bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(time_history[i])[0:3] - \
            bodies.get_body(reference_body).state_in_base_frame_from_ephemeris(time_history[i])[0:3]

        distance_to_antenna_body = np.linalg.norm(position_wrt_reference_body)

        link_budget_history[i] = transmitted_power * transmitter_antenna_gain * receiver_antenna_gain * wavelength ** 2 / \
                                 (4 * np.pi * distance_to_antenna_body) ** 2

    return link_budget_history

###########################################################################
def communications_time_per_day(bodies: tudatpy.kernel.numerical_simulation.environment.SystemOfBodies,
                                time_history: np.ndarray,
                                spacecraft_name: str,
                                ground_station_name: str,
                                minimum_elevation: float,
                                ground_station_body: str = 'Earth') -> np.ndarray:
    """
    Calculates the time available for communications per day. Only takes into account the elevation as
    seen from the ground station. Values are calculated at the time stamps provided as input.
    Default values:
    - Ground station body is Earth
    """

    # Retrieve state history
    state_history = np.zeros((np.size(time_history),6))
    for i in range(len(time_history)):
        state_history[i,:] = bodies.get_body(spacecraft_name).state_in_base_frame_from_ephemeris(time_history[i])

    # Retrieve elevation history for a sufficient number of time stamps
    elevation_time_history = np.arange(time_history[0],time_history[-1],constants.JULIAN_DAY/STATES_PER_DAY)
    elevation_history = environment_setup.get_target_elevation_angles(bodies.get_body(ground_station_body),
                                                                      bodies.get_body(spacecraft_name),
                                                                      ground_station_name,
                                                                      elevation_time_history)
    elevation_history = np.array(elevation_history)

    # Calculate time available for communications
    comms_time_per_day, comms_time_history = src.TrajectoryAnalysis.calculate_communications_time_per_day(
        elevation_history,
        elevation_time_history,
        minimum_elevation)

    # Get comms history as dictionary
    full_comms_history_dict = src.TrajectoryAnalysis.variable_history_nparray2dict(comms_time_per_day, comms_time_history)

    # Create interpolator
    interpolator_settings = interpolators.lagrange_interpolation(
        6, boundary_interpolation = interpolators.extrapolate_at_boundary)
    interpolator = interpolators.create_one_dimensional_scalar_interpolator(full_comms_history_dict, interpolator_settings)

    # Interpolate comms time per day at the specified time stamps
    comms_time_per_day_history_out = np.zeros(np.shape(time_history))
    for i in range(len(time_history)):
        comms_time_per_day_history_out[i] = interpolator.interpolate(time_history[i])

    return comms_time_per_day_history_out