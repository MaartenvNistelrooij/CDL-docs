# General imports
from typing import List
import numpy as np
import os

# Tudat imports
from tudatpy.kernel.trajectory_design import transfer_trajectory
import tudatpy

###########################################################################
def get_all_pareto_info(costs: np.ndarray,
                        trajectory_parameters: np.ndarray):
    """
    Returns the individuals that form a Pareto front and returns the corresponding fitness values and trajectory parameters
    """
    is_efficient = np.ones(costs.shape[0], dtype=bool)

    pareto = []
    pareto_parameters = []

    for i, c in enumerate(costs):
        is_efficient[i] = np.all(np.any(costs[:i] >= c, axis=1)) and np.all(np.any(costs[i + 1:] >= c, axis=1))
        if is_efficient[i] == 1:
            pareto.append(list(costs[i, :]))
            pareto_parameters.append(list(trajectory_parameters[i, :]))

    pareto = np.asarray(pareto)
    pareto_parameters = np.asarray(pareto_parameters)

    order = pareto[:, 1].argsort()

    pareto = pareto[order]
    pareto_parameters = pareto_parameters[order]

    return pareto, pareto_parameters


###########################################################################
def get_user_input_for_analysis(transfer_body_orders: List[str]):
    """
    Lets the user input info about the solutions (s)he wants to exploit further
    """
    input_correct = False
    while input_correct == False:
        print()
        print('------------------------------------------------------')
        if len(transfer_body_orders) == 1:
            desired_body_order = 0
        else:
            print()
            print('You have the following transfer body orders available: ')
            for i in range( len(transfer_body_orders) ):
                print(f'{i}: ',transfer_body_orders[i])
            print()
            desired_body_order = input('Provide the list index (0 to ' + str(
                len(transfer_body_orders) - 1) + ') of the transfer body order that you wish: ')

        try:
            desired_body_order = int(desired_body_order)
        except:
            print('Bad input, an integer is required, please specify again')
            continue

        if (desired_body_order > (len(transfer_body_orders) - 1)) or (desired_body_order < 0):
            print('There are ', len(transfer_body_orders),
                  ' transfer body orders, please choose a value from 0 to ', (len(transfer_body_orders) - 1))
            continue

        desired_type = input("Do you want to specify the desired delta v (dv) or time of flight (tof)? ")

        if desired_type == 'dv':
            print()
            desired_values = input('Provide your desired delta v (km/s) (you can specify multiple, to do so separate '
                                   'each with a comma): ')

            try:
                desired_values = [float(desired_value) * 1000 for desired_value in desired_values.split(',')]
                input_correct = True
            except:
                print('Bad input, please specify again')
                continue

        elif desired_type == 'tof':
            print()
            desired_values = input('Provide your desired time of flight (days) (you can specify multiple, to do so '
                                   'separate each with a comma: ')

            try:
                desired_values = [float(desired_value) * 86400 for desired_value in desired_values.split(',')]
                input_correct = True
            except:
                print('Bad input, please specify again')
                continue

        else:
            print('Bad input, please specify again')
            continue

        print()

    return desired_body_order, desired_type, desired_values


###########################################################################
def get_closest_pareto_solutions(desired_type: str,
                                 desired_value: float,
                                 pareto_fitness: np.ndarray,
                                 pareto_parameters: np.ndarray):
    """
        Searches for the solution that lies closest to the input value on the Pareto front \n
        Input: \n
        - desired_type: dv or tof \n
        - desired_value: float \n
        - pareto_fitness: list[float] \n
        - pareto_parameters: list[list[float]] \n
        Returns: \n
        - best_fitness
        - best_parameters

    """
    if desired_type == 'dv':
        abs_differences = abs(pareto_fitness[:, 0] - desired_value)
        best_index = np.argmin(abs_differences)
        best_fitness = pareto_fitness[best_index]
        best_parameters = pareto_parameters[best_index]
    elif desired_type == 'tof':
        abs_differences = abs(pareto_fitness[:, 1] - desired_value)
        best_index = np.argmin(abs_differences)
        best_fitness = pareto_fitness[best_index]
        best_parameters = pareto_parameters[best_index]

    return best_fitness, best_parameters


###########################################################################
def get_transfer_body_order_abbreviation(transfer_body_order: List[str]) -> str:
    """
    Returns an abbreviation for a sequence of planets
    """
    abbrev = ''
    i = 0
    for planet in transfer_body_order:
        abbrev += planet[0]
        i += 1

    return abbrev

###########################################################################
def select_results_directory(transfer_body_order: List[str],
                             leg_type: tudatpy.kernel.trajectory_design.transfer_trajectory.TransferLegTypes,
                             current_dir: str) -> str:
    """
    Determines the path of the directory where the results are saved
    """
    transfer_body_order_abbreviation = get_transfer_body_order_abbreviation(transfer_body_order)

    if leg_type == transfer_trajectory.unpowered_unperturbed_leg_type:
        results_dir = current_dir + '/MGA_noDSM_' + transfer_body_order_abbreviation + '/'
    elif leg_type == transfer_trajectory.dsm_velocity_based_leg_type:
        results_dir = current_dir + '/MGA_DSM_' + transfer_body_order_abbreviation + '/'

    return results_dir

###########################################################################
def get_trajectory_parameters_of_desired_solutions(leg_type,
                                                   transfer_body_order: List[str],
                                                   type: str,
                                                   values: List[float],
                                                   current_dir: str):

    """"
    Loads data closest to the desired solutions and returns the transfer trajectory object, the trajectory parameters
    for these solutions and the repository names where the plots for these are to be stored.
    """

    results_dir = select_results_directory(transfer_body_order, leg_type, current_dir) + 'optimization/'

    pareto_fitness = np.loadtxt(results_dir + 'Pareto_fitness.dat', dtype=float, unpack=False)
    pareto_parameters = np.loadtxt(results_dir + 'Pareto_parameters.dat', dtype=float, unpack=False)

    trajectory_parameters_list = []

    for value in values:
        # Obtain solution on the Pareto front that is closed to the desired value
        best_fitness, best_trajectory_parameters = get_closest_pareto_solutions(type,
                                                                                value,
                                                                                pareto_fitness,
                                                                                pareto_parameters)
        trajectory_parameters_list.append(best_trajectory_parameters)

    return trajectory_parameters_list

###########################################################################
def get_user_input_for_saving(transfer_body_orders: List[str],
                              current_dir: str,
                              leg_type: tudatpy.kernel.trajectory_design.transfer_trajectory.TransferLegTypes):
    """
       Lets the user input info about the solutions (s)he wants to save to Excel
    """

    input_correct = False
    while input_correct == False:
        if len(transfer_body_orders) == 1:
            desired_index = 0
            input_correct = True
        else:
            print('You have the following transfer body orders available: ')
            for i in range(len(transfer_body_orders)):
                print(f'{i}: ', transfer_body_orders[i])
            print()

            desired_index = input('Provide the transfer body order index (0 to ' + str(
                        len(transfer_body_orders) - 1) + ') that you want to save: ')

            try:
                desired_index = int(desired_index)

            except:
                print('Bad input, an integer is required, please specify again')
                continue

            if (desired_index > (len(transfer_body_orders) - 1)) or (desired_index < 0):
                print('There are ', len(transfer_body_orders),
                      ' transfer body orders, please choose a value from 0 to ', (len(transfer_body_orders) - 1))
                continue

            input_correct = True

    transfer_body_order_desired = transfer_body_orders[desired_index]

    case_dir = select_results_directory(transfer_body_order_desired, leg_type, current_dir)

    available_dirs = os.listdir(case_dir)

    input_correct = False
    while input_correct == False:
        if len(available_dirs) == 0:
            print()
            print('You do not have optimized and analysed results available, please run transfer_trajectory_optimization.py'
                  ' and transfer_trajectory_analysis.py first!')
            exit()
        elif (len(available_dirs) == 1) and ('optimization' in available_dirs):
            print()
            print('You do not have analysed results available, please run transfer_trajectory_analysis.py first')
            exit()
        elif (len(available_dirs) == 2) and ('optimization' in available_dirs):
            if available_dirs[0] == 'optimization':
                desired_index = 1
            else: # same as available_dirs[1] == 'optimization':
                desired_index = 0
            input_correct = True
        else:
            if 'optimization' in available_dirs:
                available_dirs.remove('optimization')
            print()
            print('You have the following cases available: ')
            for i in range(len(available_dirs)):
                print(f'{i}: ', available_dirs[i])
            print()
            desired_index = input('Provide the case index  (0 to ' + str(
                len(available_dirs) -  1) + ') that you want to save: ')
            try:
                desired_index = int(desired_index)
            except:
                print('Bad input, an integer is required, please specify again')
                continue

            if (desired_index > (len(available_dirs) - 1)) or (desired_index < 0):
                print()
                print('There are ', len(available_dirs),
                      ' available cases, please choose a value from 0 to ', (len(available_dirs) - 1), '\n')
                continue

            input_correct = True

    desired_dir_to_save = case_dir + available_dirs[desired_index]

    print()
    print('Saving ', desired_dir_to_save)
    print()

    return desired_dir_to_save

