
# J. J. Lissauer and I. de Pater. Fundamental Planetary Sciences. Cambridge University Press, updated edition, 2019.
SOLAR_LUMINOSITY = 3.827e26  # [W]

# Equatorial radii - Unit: [m]
EARTH_EQUATORIAL_RADIUS = 6378136.6  # IERS, 2010
