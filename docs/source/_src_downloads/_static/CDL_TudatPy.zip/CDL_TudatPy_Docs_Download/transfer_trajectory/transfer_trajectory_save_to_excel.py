# General imports
import os
import pandas as pd
import numpy as np
import regex as re
import xlsxwriter
from openpyxl import load_workbook

# CDL imports
from transfer_trajectory_inputs import transfer_body_orders, leg_type
from src import TransferTrajectoryUtilities

def main():

    print()
    print('This script will save trajectory analysis results to Excel')
    print()

    current_dir = os.getcwd()

    # Set the destination directory for the Excel file
    excel_path = current_dir + '/Transfer_trajectory.xlsx'

    # Create the Excel file if it does not exist yet
    if not os.path.isfile(excel_path):
        open(excel_path, 'w').close()

    # Get user input on which transfer trajectory case to save
    dir_to_save = TransferTrajectoryUtilities.get_user_input_for_saving(transfer_body_orders,
                                                                        current_dir,
                                                                        leg_type)

    with open(dir_to_save + '/trajectory_info.txt') as fp:
        for line in fp:
            if len(re.findall("TOF", line)) > 0:
                tof = float(re.findall("\d+\.\d+", line)[0])
            elif len(re.findall('leg', line)) > 0:
                dv_per_leg = np.array(re.findall("\d+\.\d+", line)).astype('float')
            elif len(re.findall('node', line)) > 0:
                dv_per_node= np.array(re.findall("\d+\.\d+", line)).astype('float')
            elif len(re.findall("Delta", line)) > 0:
                dv = float(re.findall("\d+\.\d+", line)[0])

    # Save trajectory information to Excel
    wb = xlsxwriter.Workbook(excel_path)
    ws = wb.add_worksheet('Results 1')
    ws.write(0, 0, 'TOF [days]')
    ws.write(0, 1, tof)
    ws.write(1, 0, 'Delta V [m/s]')
    ws.write(1, 1, dv)
    ws.write(2, 0, 'Delta V per leg [m/s]')
    for i in range(len(dv_per_leg)):
        ws.write(2, i+1, dv_per_leg[i])
    ws.write(3, 0, 'Delta V per node [m/s]')
    for i in range(len(dv_per_node)):
        ws.write(3, i + 1, dv_per_node[i])
    wb.close()

    # Set pandas excel writer to save analysis results
    book = load_workbook(excel_path)
    writer = pd.ExcelWriter(excel_path, engine='openpyxl')
    writer.book = book

    # Read analysis results
    comms_time = pd.read_csv(dir_to_save + '/trajectory_analysis_data/comms_time.txt', sep=' ')
    link_budget = pd.read_csv(dir_to_save + '/trajectory_analysis_data/link_budget.txt', sep=' ')
    solar_flux = pd.read_csv(dir_to_save + '/trajectory_analysis_data/solar_flux.txt', sep=' ')
    state_wrt_earth = pd.read_csv(dir_to_save + '/trajectory_analysis_data/state_wrt_earth.txt', sep=' ')
    state_wrt_sun = pd.read_csv(dir_to_save + '/trajectory_analysis_data/state_wrt_sun.txt', sep=' ')

    # Save analysis results to Excel
    comms_time.to_excel(writer, sheet_name='Results 2', columns=[comms_time.keys()[0], comms_time.keys()[1]], header=['Time [s]', 'Communication time per day [s]'], index=False, startcol=0, freeze_panes=(1,1))
    link_budget.to_excel(writer, sheet_name='Results 2', columns=[link_budget.keys()[0], link_budget.keys()[1]], header=['Time [s]', 'Link budget [W]'], index=False, startcol=3, freeze_panes=(1,1))
    solar_flux.to_excel(writer, sheet_name='Results 2', columns=[solar_flux.keys()[0], solar_flux.keys()[1]], header=['Time [s]', 'Solar Flux [W/m2]'], index=False, startcol=6, freeze_panes=(1,1))
    state_wrt_earth.to_excel(writer, sheet_name='Results 2', columns=[state_wrt_earth.keys()[0], state_wrt_earth.keys()[1], state_wrt_earth.keys()[2], state_wrt_earth.keys()[3], state_wrt_earth.keys()[4], state_wrt_earth.keys()[5],state_wrt_earth.keys()[6]], header=['Time [s]', 'x Earth [m]', 'y Earth [m]', 'z Earth [m]', 'vx Earth [m/s]', 'vy Earth [m/s]', 'vz Earth [m/s]'], index=False, startcol=9, freeze_panes=(1,1))
    state_wrt_sun.to_excel(writer, sheet_name='Results 2', columns=[state_wrt_sun.keys()[0], state_wrt_sun.keys()[1], state_wrt_sun.keys()[2], state_wrt_sun.keys()[3], state_wrt_sun.keys()[4], state_wrt_sun.keys()[5],state_wrt_sun.keys()[6]], header=['Time [s]', 'x Sun [m]', 'y Sun [m]', 'z Sun [m]', 'vx Sun [m/s]', 'vy Sun [m/s]', 'vz Sun [m/s]'], index=False, startcol=17, freeze_panes=(1,1))

    # Save the file
    writer.save()

    return 0

if __name__ == "__main__":    main()

