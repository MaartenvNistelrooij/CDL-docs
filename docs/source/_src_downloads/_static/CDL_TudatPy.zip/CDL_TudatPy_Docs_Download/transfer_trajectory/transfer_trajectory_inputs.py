# Tudat imports
from tudatpy.kernel.trajectory_design import transfer_trajectory
from tudatpy.kernel import constants

# General imports
import numpy as np

###########################################################################
# Define transfer trajectory properties
###########################################################################

# Define order of bodies (nodes)
transfer_body_orders = [['Earth', 'Venus', 'Venus', 'Earth', 'Jupiter', 'Saturn'],
                        ['Earth', 'Jupiter', 'Saturn']]

# Select type of transfer
# Valid options: - transfer_trajectory.unpowered_unperturbed_leg_type
#                - transfer_trajectory.dsm_velocity_based_leg_type

leg_type = transfer_trajectory.unpowered_unperturbed_leg_type

# Set departure date its margin
departure_date = (-789.8117 - 0.5) * constants.JULIAN_DAY
departure_date_margin = 180.0 * constants.JULIAN_DAY

# Define departure orbit
departure_semi_major_axis = np.inf              # Optional
departure_eccentricity = 0                      # Optional

# Define insertion orbit
arrival_semi_major_axis = 1.0895e8 / 0.02       # Optional
arrival_eccentricity = 0.98                     # Optional

###########################################################################
# Define variables used in the optimization
###########################################################################
# Set optimization parameters - see guidelines on https://cdl-docs.readthedocs.io/en/latest/
number_of_evolutions = 3000
population_size = 500
optimization_seed = 4444                        # Optional

# Set maximum Delta V acceptable during the optimization
maximum_delta_v = 2e8  # [m/s]

# Set whether optimization plots are saved
save_optimization_plots = True

###########################################################################
# Define variables used for analysis of the transfer trajectories
###########################################################################
# Select properties for calculation of link budget
transmited_power = 27  # W
transmiter_antenna_gain = 10
receiver_antenna_gain = 1
frequency = 1.57542e9  # Hz

# Select ground station used
minimum_elevation = 10 * np.pi / 180
gs_latitude = 52.0115769 * np.pi / 180
gs_longitude = 4.3570677 * np.pi / 180
station_name = 'Delft'

# Set whether analysis plots are saved
save_analysis_plots = True

###########################################################################
# Define time of flight ranges used in optimization
###########################################################################
# Minimum and maximum times of flight TOWARDS each of the specified bodies [day]
# WARNING: SEE CDL DOCUMENTATION BEFORE CHANGING THESE VALUES!
MINIMUM_TIME_OF_FLIGHT_DICT = {
    'Mercury': 100,
    'Venus': 100,
    'Earth': 50,
    'Moon': 0.1,
    'Mars': 100,
    'Jupiter': 800,
    'Saturn': 3000,
    'Uranus': 1500,
    'Neptune': 3000,
    'Pluto': 6000
}

MAXIMUM_TIME_OF_FLIGHT_DICT = {
    'Mercury': 1000,
    'Venus': 1000,
    'Earth': 1000,
    'Moon': 1000,
    'Mars': 1000,
    'Jupiter': 4000,
    'Saturn': 8000,
    'Uranus': 15000,
    'Neptune': 30000,
    'Pluto': 50000
}