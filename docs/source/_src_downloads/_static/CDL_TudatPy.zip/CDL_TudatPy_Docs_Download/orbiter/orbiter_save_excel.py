# General imports
import os
import pandas as pd
import numpy as np
import regex as re
import xlsxwriter
from openpyxl import load_workbook

# CDL imports

def main():

    print()
    print('This script will save trajectory analysis results to Excel')
    print()

    current_dir = os.getcwd()

    # Set the destination directory for the Excel file
    excel_path = current_dir + '/Orbiter.xlsx'

    # Create the Excel file if it does not exist yet
    if not os.path.isfile(excel_path):
        open(excel_path, 'w').close()

    # Get user input on which obiter case to save
    available_dirs = os.listdir(current_dir)
    available_cases = [case for case in available_dirs if 'Orbiter_' in case]
    print('Available cases: ')
    for case in available_cases:
        print(case)
    print()
    orbiter_index = input('Provide the case index (1-' + str(len(available_cases)) + ') that you want to save to Excel: ')

    dir_to_save = current_dir + '/Orbiter_' + str(orbiter_index) + '/'
    print('Saving ', dir_to_save)
    print()

    # Save orbit characteristics to Excel
    with open(dir_to_save + '/orbiter_analysis_data/simple_characteristics.txt') as fp:
        for line in fp:
            if len(re.findall("Minimum", line)) > 0:
                lat_min = float(re.findall("\d+\.\d+", line)[0])
            elif len(re.findall('Maximum', line)) > 0:
                lat_max = np.array(re.findall("\d+\.\d+", line)).astype('float')
            elif len(re.findall('Surface', line)) > 0:
                percentage_surface_covered = np.array(re.findall("\d+\.\d+", line)).astype('float')

    wb = xlsxwriter.Workbook(excel_path)
    ws = wb.add_worksheet('Simple characteristics')
    ws.write(0, 0, 'Minimum latitude [deg]')
    ws.write(0, 1, lat_min)
    ws.write(1, 0, 'Maximum latitude [deg]')
    ws.write(1, 1, lat_max)
    ws.write(2, 0, 'Surface covered [%]')
    ws.write(2, 1, percentage_surface_covered)
    wb.close()

    # Set pandas excel writer to save analysis results
    book = load_workbook(excel_path)
    writer = pd.ExcelWriter(excel_path, engine='openpyxl')
    writer.book = book

    # Read analysis results
    inputs = pd.read_csv(dir_to_save + 'inputs.txt', sep='  ', engine='python')
    state = pd.read_csv(dir_to_save + '/orbiter_analysis_data/state.txt', sep=' ')
    dependent_variables = pd.read_csv(dir_to_save + '/orbiter_analysis_data/dependent_variables.txt', sep=' ')
    eclipses = pd.read_csv(dir_to_save + '/orbiter_analysis_data/eclipses.txt', sep=' ')
    day_night = pd.read_csv(dir_to_save + '/orbiter_analysis_data/planet_day_night_side.txt', sep=' ')
    los_to_gs = pd.read_csv(dir_to_save + '/orbiter_analysis_data/los_to_ground_station.txt', sep=' ')
    los_to_rs = pd.read_csv(dir_to_save + '/orbiter_analysis_data/los_to_relay_satellite.txt', sep=' ')
    number_of_visitations = pd.read_csv(dir_to_save + '/orbiter_analysis_data/number_of_visitations.txt', sep=' ')
    shortest_revisit_time = pd.read_csv(dir_to_save + '/orbiter_analysis_data/shortest_revisit_time.txt', sep=' ')
    mean_revisit_time = pd.read_csv(dir_to_save + '/orbiter_analysis_data/mean_revisit_time.txt', sep=' ')
    longest_revisit_time = pd.read_csv(dir_to_save + '/orbiter_analysis_data/longest_revisit_time.txt', sep=' ')

    # Save analysis results to Excel
    inputs.to_excel(writer, sheet_name='Inputs', columns=[inputs.keys()[0], inputs.keys()[1]], header=['Variable', 'Quantity'], index=False, startcol=0, freeze_panes=(1,1))
    state.to_excel(writer, sheet_name='Results', columns=[state.keys()[0]], header=['Time [s]'], index=False, startcol=0, freeze_panes=(1,1))
    state.to_excel(writer, sheet_name='Results', columns=[state.keys()[1], state.keys()[2], state.keys()[3], state.keys()[4], state.keys()[5],state.keys()[6]], header=['x Earth [m]', 'y Earth [m]', 'z Earth [m]', 'vx Earth [m/s]', 'vy Earth [m/s]', 'vz Earth [m/s]'], index=False, startcol=2, freeze_panes=(1,1))
    eclipses.to_excel(writer, sheet_name='Results', columns=[eclipses.keys()[1]], header=['Eclipses (full light=1, umbra=0) [-]'], index=False, startcol=9, freeze_panes=(1,1))
    day_night.to_excel(writer, sheet_name='Results', columns=[day_night.keys()[1]], header=['Day(=1)/Night(=0) [-]'], index=False, startcol=11, freeze_panes=(1,1))
    los_to_gs.to_excel(writer, sheet_name='Results', columns=[los_to_gs.keys()[1]], header=['LoS GS (1=LoS, 0=no LoS) [-]'], index=False, startcol=13, freeze_panes=(1,1))
    los_to_rs.to_excel(writer, sheet_name='Results', columns=[los_to_rs.keys()[1]], header=['LoS RS (1=LoS, 0=no LoS) [-]'], index=False, startcol=15, freeze_panes=(1,1))

    for i in range(len(dependent_variables.keys())):
        if i == 0:
            dependent_variables.to_excel(writer, sheet_name='Results', columns=[dependent_variables.keys()[i]], header=['Time [s]'], index=False, startcol=17, freeze_panes=(1,1))
        else:
            dependent_variables.to_excel(writer, sheet_name='Results', columns=[dependent_variables.keys()[i]], header=['Dep. var. ' + str(i)], index=False, startcol=17+i, freeze_panes=(1,1))

    number_of_visitations.to_excel(writer, sheet_name='Grid', columns=[number_of_visitations.keys()[0], number_of_visitations.keys()[1], number_of_visitations.keys()[2]], header=['Longitude [deg]', 'Latitude [deg]', 'Number of visits'], index=False, startcol=0, freeze_panes=(1,2))
    shortest_revisit_time.to_excel(writer, sheet_name='Grid', columns=[shortest_revisit_time.keys()[2]], header=['Shortest revisit time [s]'], index=False, startcol=3, freeze_panes=(1,2))
    mean_revisit_time.to_excel(writer, sheet_name='Grid', columns=[mean_revisit_time.keys()[2]], header=['Mean revisit time [s]'], index=False, startcol=4, freeze_panes=(1,2))
    longest_revisit_time.to_excel(writer, sheet_name='Grid', columns=[longest_revisit_time.keys()[2]], header=['Longest revisit time [s]'], index=False, startcol=5, freeze_panes=(1,2))

    # Save the file
    writer.save()

    return 0

if __name__ == "__main__":    main()

