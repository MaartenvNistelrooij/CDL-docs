# TudatPy imports
from tudatpy.kernel import constants
from tudatpy.kernel.numerical_simulation import propagation_setup

# General imports
import numpy as np

###########################################################################
# Define general settings
###########################################################################

save_analysis_plots = True

central_body = 'Mars'

# Spacecraft properties
spacecraft_name = 'If found, please return to Earth'
vehicle_mass = 2000  # kg
radiation_pressure_coefficient = 1.2  # set to None if not applicable
reference_area = 50  # m^2, set to None if not applicable

# Simulation time period
simulation_start_epoch = 5000.35 * constants.JULIAN_DAY  # seconds
simulation_time = 30. * constants.JULIAN_DAY  # seconds

###########################################################################
# Define spacecraft initial state with respect to central body
###########################################################################
# Semi major axis in meters, angles in radians
semi_major_axis = 7000e3
eccentricity = 0.5
inclination = 0.0 * np.pi/180.
raan = 0.0 * np.pi/180.
aop = 0.0 * np.pi/180.
tr_anom = 0.0 * np.pi/180.

###########################################################################
# Define ground station properties
###########################################################################

minimum_elevation = 10 * np.pi / 180
gs_latitude = 52.0115769 * np.pi / 180
gs_longitude = 4.3570677 * np.pi / 180
gs_name = 'Delft'

###########################################################################
# Define relay satellite properties
###########################################################################
# Central body and name
rs_central_body = "Earth"
rs_name = "RelaySat"

# Initial state wrt central body
rs_semi_major_axis = 42164.0e3
rs_eccentricity = 0.0
rs_inclination = 0.0 * np.pi/180.
rs_raan = 0.0 * np.pi/180.
rs_aop = 0.0 * np.pi/180.
rs_tr_anom = 0.0 * np.pi/180.

###########################################################################
# Define instrument properties
###########################################################################

field_of_view = 5.  # degrees

###########################################################################
# Accelerations and dependent variables
###########################################################################
acceleration_settings_on_vehicle = {"Mars": [propagation_setup.acceleration.spherical_harmonic_gravity(4,0)],
                                    "Earth": [propagation_setup.acceleration.point_mass_gravity()],
                                    "Jupiter": [propagation_setup.acceleration.point_mass_gravity()],
                                    "Saturn": [propagation_setup.acceleration.point_mass_gravity()],
                                    "Sun": [propagation_setup.acceleration.point_mass_gravity(),
                                            propagation_setup.acceleration.cannonball_radiation_pressure()]
                                    }

#############################################################################
#                            IMPORTANT NOTE                                 #
#                                                                           #
#         Below you can add dependent variables that are saved during       #
#         the propagation.                                                  #
#         The first two entries (altitude and central body fixed            #
#         spherical position) are used within the script and should         #
#         therefore remain the first two entries. DO NOT change that.       #
#         Entries 3 and further can be changed as desired.                  #
#                                                                           #
#############################################################################

dependent_variables_to_save = [propagation_setup.dependent_variable.altitude(spacecraft_name, central_body),  # DO NOT CHANGE
                               propagation_setup.dependent_variable.central_body_fixed_spherical_position(spacecraft_name, central_body),  # DO NOT CHANGE
                               propagation_setup.dependent_variable.keplerian_state(spacecraft_name, central_body),
                               propagation_setup.dependent_variable.relative_distance(spacecraft_name, central_body),
                               propagation_setup.dependent_variable.relative_distance(spacecraft_name, "Earth"),
                               propagation_setup.dependent_variable.relative_distance(spacecraft_name, "Sun"),
                               propagation_setup.dependent_variable.relative_position("Sun",central_body)
                               ]
